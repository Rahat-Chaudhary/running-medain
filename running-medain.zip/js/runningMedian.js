//get file upload id and call getFile function.
document.getElementById("input-file").addEventListener("change", getFile);

//get file
function getFile(event) {
  const input = event.target;
  if ("files" in input && input.files.length > 0) {
    placeFileContent(document.getElementById("content-target"), input.files[0]);
  }
}
// calculate the medain and output the result.
function placeFileContent(target, file) {
  readFileContent(file)
    .then(content => {
      let array = content.split("\n");
      array.pop();
      let arrOfNumber = array.map(item => parseInt(item).toFixed(1));
      console.log(arrOfNumber);
      const length = arrOfNumber[0];
      let output = "";
      output += `${arrOfNumber[1]} \n`;

      for (let i = 2; i <= length; i++) {
        if (i % 2 === 0) {
          console.log("Even: ", i);
          let median = Math.ceil(i / 2);
          let res =
            (Number(arrOfNumber[median]) + Number(arrOfNumber[median + 1])) / 2;
          output += `${res.toFixed(1)} \n`;
        } else {
          let median = Math.ceil(i / 2);
          console.log("odd: ", i);
          output += `${arrOfNumber[median]} \n`;
        }
      }

      target.value = output;
    })
    .catch(error => console.log(error));
}

//read the input file.
function readFileContent(file) {
  const reader = new FileReader();
  return new Promise((resolve, reject) => {
    reader.onload = event => resolve(event.target.result);
    reader.onerror = error => reject(error);
    reader.readAsText(file);
  });
}
